package parte1;

import java.util.ArrayList;
import java.util.List;

public class Loja {
	private List<Fornecedor> fornecedores;
	private int quantFornecedores = 0;
	private List<Produto> produtos;
	private int quantidadeP = 0;

	public Loja() {
		fornecedores = new ArrayList<>();
		produtos = new ArrayList<>();
	}

	public String listaFornecedores() {
		StringBuilder sb = new StringBuilder();
		if (!fornecedores.isEmpty()) {
			sb.append("**********Lista de Fornecedores da Loja**********\n");
			for (int i = 0; i < fornecedores.size(); i++) {
				if (fornecedores.get(i) != null) {
					sb.append(fornecedores.get(i).getNumero() + ". Nome: " + fornecedores.get(i).getNome()
							+ ",  Código: " + fornecedores.get(i).getCodigo() + "\n");
				}
			}
			sb.append("*************************************************\n");
		}
		return sb.toString();
	}

	public String listaProdutos() {
		StringBuilder sb = new StringBuilder();
		if (!produtos.isEmpty()) {
			sb.append("**********Lista de Produtos da loja**********\n");
			for (int i = 0; i < produtos.size(); i++) {
				if (produtos.get(i) != null) {
					sb.append(produtos.get(i).getNumero() + ". Nome: " + produtos.get(i).getNome() + ",  Codigo: "
							+ produtos.get(i).getCodigo() + "\n");
				}
			}
			sb.append("*********************************************\n");
		}
		return sb.toString();
	}

	public boolean adicionarCadastroFornecedores(Fornecedor fornecedor) {
		fornecedores.add(fornecedor);
		fornecedor.setNumero(quantFornecedores + 1);
		quantFornecedores++;
		return true;
	}

	public Fornecedor alterarFonecedor(int numero) {
		for (int j = 0; j < fornecedores.size(); j++) {
			if (fornecedores.get(j).getNumero() == numero) {
				return fornecedores.get(j);
			}
		}
		return null;
	}

	public boolean excluirFornececedor(int numero) {
		for (int i = 0; i < fornecedores.size(); i++) {
			if (fornecedores.get(i).getNumero() == numero) {
				for (int j = i; j < fornecedores.size() - 1; j++) {
					fornecedores.get(j + 1).setNumero(fornecedores.get(j + 1).getNumero() - 1);
				}
				quantFornecedores--;
				fornecedores.remove(i);
				return true;
			}
		}
		return false;
	}

	public String consultarFornecedorPorNome(String nome) {
		for (int j = 0; j < fornecedores.size(); j++) {
			if (fornecedores.get(j).getNome().equalsIgnoreCase(nome)) {
				return imprimeFornecedor(fornecedores.get(j));

			}
		}
		return null;
	}

	private String imprimeFornecedor(Fornecedor fornecedor) {
		StringBuilder sb = new StringBuilder();
		int flag = 0;
		if (fornecedor != null) {
			sb.append("\nDADOS DO FORNECEDOR:\n");
			sb.append("Nome: " + fornecedor.getNome() + "\nDescrição: " + fornecedor.getDescricao() + "\nTelefone: "
					+ fornecedor.getTelefone() + "\nEmail: " + fornecedor.getEmail());
			sb.append("\nEndereco: \nRua: " + fornecedor.getEndereco().getRua() + ", Complemento: "
					+ fornecedor.getEndereco().getComplemento() + ", Bairro: " + fornecedor.getEndereco().getBairro()
					+ ", CEP: " + fornecedor.getEndereco().getCep() + ", Cidade: "
					+ fornecedor.getEndereco().getCidade() + ", Estado: " + fornecedor.getEndereco().getEstado()
					+ "\n");
			sb.append("\nPRODUTOS DESTE FORNECEDOR:\n");
			for (int k = 0; k < produtos.size(); k++) {
				if (produtos.get(k).getFornecedor() == fornecedor) {
					sb.append(produtos.get(k).getNumero() + ". Nome: " + produtos.get(k).getNome() + ",  Código: "
							+ produtos.get(k).getCodigo());
					flag = 1;
				}
			}

		}
		if (flag == 0) {
			sb.append("\nEste Fornecedor ainda não possui cadastros de Produtos!\n");
		}
		return sb.toString();
	}

	public String consultarFornecedorPorCodigo(String codigo) {
		for (int j = 0; j < fornecedores.size(); j++) {
			if (fornecedores.get(j).getCodigo().equalsIgnoreCase(codigo)) {
				return imprimeFornecedor(fornecedores.get(j));
			}
		}
		return null;
	}

	public Fornecedor procurarFornecedor(int numero) {
		for (int i = 0; i < fornecedores.size(); i++) {
			if (fornecedores.get(i).getNumero() == numero) {
				return fornecedores.get(i);
			}
		}
		return null;
	}

	public boolean adicionarCadastroProduto(Produto produto) {
		produtos.add(produto);
		produto.setNumero(quantidadeP + 1);
		quantidadeP++;
		return true;
	}

	public Produto alterarProduto(int numero) {
		for (int i = 0; i < produtos.size(); i++) {
			if (produtos.get(i).getNumero() == numero) {
				return produtos.get(i);
			}
		}
		return null;
	}

	public boolean excluirProduto(int numero) {
		for (int i = 0; i < produtos.size(); i++) {
			if (produtos.get(i).getNumero() == numero) {
				for (int j = i; j < produtos.size() - 1; j++) {
					produtos.get(j + 1).setNumero(produtos.get(j + 1).getNumero() - 1);
				}
				produtos.remove(i);
				quantidadeP--;
				return true;
			}
		}
		return false;
	}

	private String imprimeProduto(Produto produto) {
		StringBuilder sb = new StringBuilder();
		if (produto != null) {
			sb.append("\nDADOS DO PRODUTO:\n");
			sb.append("Nome: " + produto.getNome() + "\nDescricao: " + produto.getDescricao() + "\nCodigo: "
					+ produto.getCodigo() + "\nPreço R$ " + produto.getEstoque().getPreco() + "\nQuantidade: "
					+ produto.getEstoque().getQuantidade());
			sb.append("\n\nFORNECEDOR:" + "\nNome: " + produto.getFornecedor().getNome() + "\n");
		}
		return sb.toString();
	}

	public String consultarProdutoPorNome(String nome) {
		for (int i = 0; i < produtos.size(); i++) {
			if (produtos.get(i).getNome().equalsIgnoreCase(nome)) {
				return imprimeProduto(produtos.get(i));
			}
		}
		return null;
	}

	public String consultarProdutoPorCodigo(String codigo) {
		for (int i = 0; i < produtos.size(); i++) {
			if (produtos.get(i).getCodigo().equalsIgnoreCase(codigo)) {
				return imprimeProduto(produtos.get(i));
			}
		}
		return null;
	}

	public Produto manutencaoEstoque(int numero) {
		for (int i = 0; i < produtos.size(); i++) {
			if (produtos.get(i).getNumero() == numero) {
				return produtos.get(i);
			}
		}
		return null;
	}

	public List<Produto> produtoPesquisado(String palavraChave) {
		List<Produto> produtosRelacionados = new ArrayList<>();
		for (int i = 0; i < produtos.size(); i++) {
			if (produtos.get(i).getCodigo().equalsIgnoreCase(palavraChave)
					|| produtos.get(i).getNome().toLowerCase().startsWith(palavraChave)) {
				produtosRelacionados.add(produtos.get(i));
			}
		}
		return produtosRelacionados;
	}

	public void alterarEstoque(String nome, int quantidade) {
		for (int i = 0; i < produtos.size(); i++) {
			if (produtos.get(i).getNome().equals(nome)) {
				produtos.get(i).getEstoque().setQuantidade(produtos.get(i).getEstoque().getQuantidade() - quantidade);
			}
		}
	}
}
