package parte1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import parte2.CadastroCliente;
import parte2.Cliente;
import parte2.ItemPedido;
import parte2.Pedido;

public class Main {

	private static Scanner in = new Scanner(System.in);
	private static Loja l;
	private static CadastroCliente c;

	public static void main(String[] args) {

		try {
			l = new Loja();
			c = new CadastroCliente();

			boolean continuar = true;

			while (continuar) {

				System.out.println("----------------------Menu----------------------");
				System.out.println("************************************************");
				System.out.println("Fique a vontade para escolher umas das opções abaixo!");
				System.out.println("1. Cadastro de fornecedor");
				System.out.println("2. Cadastro de produto");
				System.out.println("3. Cadastro de Cliente");
				System.out.println("4. Manutenção de estoque");
				System.out.println("5. Consulta de fornecedor");
				System.out.println("6. Consulta de produto");
				System.out.println("7. Carrinho de compras");
				System.out.println("8. Consultar Pedidos de Cliente por Número");
				System.out.println("9. Sair");
				System.out.println("*************************************************");
				System.out.println("-------------------------------------------------");

				int opcao = in.nextInt();
				in.nextLine();

				switch (opcao) {

				case 1:
					cadastroF();
					break;
				case 2:
					cadastroP();
					break;
				case 3:
					cadastrarCliente();
					break;
				case 4:
					manutenEstoque();
					break;
				case 5:
					consultarFornecedor();
					break;
				case 6:
					consultarProduto();
					break;
				case 7:
					gerenciarProduto();
					break;
				case 8:
					consultarPedidoNumeroAdm();
					break;
				case 9:
					System.out.println("***********************");
					System.out.println("Obrigado! Volte sempre!");
					System.out.println("***********************");
					continuar = false;
					break;
				default:
					System.out.println("\nAviso: Opção invalida tente novamente!\n");

				}
			}
		} catch (java.util.InputMismatchException e) {
			System.out.println("AVISO: Digite a opção por meio de números!");
			in.nextLine();
		}

	}

	@SuppressWarnings("unchecked")
	private static void cadastroF() {

		List<Fornecedor> Fornecedores = new ArrayList<>();

		File f = new File("CadastroF.txt");
		if (f.exists()) {
			try {
				FileInputStream fi = new FileInputStream("CadastroF.txt");
				ObjectInputStream oi = new ObjectInputStream(fi);
				Object o = oi.readObject();
				Fornecedores = (List<Fornecedor>) o;
				oi.close();
				fi.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		System.out.println("***********************************");
		System.out.println("Escolha uma opção:");
		System.out.println("1. Incluir fornecedor");
		System.out.println("2. Alterar fornecedor");
		System.out.println("3. Excluir fornecedor");
		System.out.println("4. Voltar");
		System.out.println("***********************************");

		int opcao = in.nextInt();
		in.nextLine();

		switch (opcao) {

		case 1:
			System.out.println("Digite o nome do fornecedor:");
			String nome = in.nextLine();

			System.out.println("Digite sua descricao:");
			String descricao = in.nextLine();

			System.out.println("Digite o telefone:");
			String telefone = in.nextLine();

			System.out.println("Digite o email:");
			String email = in.nextLine();

			System.out.println("Digite o codigo do fornecedor:");
			String codigo = in.nextLine();

			Endereco endereco = cadastroEndereco();
			Fornecedor fornecedor = new Fornecedor(nome, descricao, telefone, email, codigo, endereco);
			boolean cadastrado = l.adicionarCadastroFornecedores(fornecedor);
			if (cadastrado) {
				System.out.println("\nFornecedor Cadastrado com Sucesso!\n");

			} else {
				System.out.println("\nNumero de Cadastros de Fornecedores Excedido!\n");
			}

			try {
				FileOutputStream fu = new FileOutputStream("CadastroF.txt");
				ObjectOutputStream ou = new ObjectOutputStream(fu);
				ou.writeObject(Fornecedores);
				ou.close();
				fu.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			for (Fornecedor CF : Fornecedores) {
				System.out.println(CF);
			}

			break;
		case 2:

			System.out.println(l.listaFornecedores());
			System.out.println("\nDigite o numero do Fornecedor que deseja alterar:");
			int num = in.nextInt();
			in.nextLine();
			fornecedor = l.alterarFonecedor(num);
			if (fornecedor != null) {
				alteraFornecedor(fornecedor);
				System.out.println("\nAlteracao de Cadastro realizada com Sucesso!\n");
			} else {
				System.out.println("\nFornecedor não Encontrado!\n");
			}
			break;
		case 3:
			System.out.println(l.listaFornecedores());
			System.out.println("Digite o numero do fornecedor que deseja excluir:");
			num = in.nextInt();
			in.nextLine();
			if (l.excluirFornececedor(num)) {
				System.out.println("\nFornecedor Excluido com Sucesso!\n");
			} else {
				System.out.println("\nFornecedor não Encontrado!\n");
			}
			break;
		case 4:
			break;
		default:
			System.out.println("\nOpcao inválida tente novamente!\n");

		}

	}

	@SuppressWarnings("unchecked")
	private static void cadastroP() {
		List<Produto> Produtos = new ArrayList<>();

		File f = new File("CadastroP.txt");
		if (f.exists()) {
			try {
				FileInputStream fi = new FileInputStream("CadastroP.txt");
				ObjectInputStream oi = new ObjectInputStream(fi);
				Object o = oi.readObject();
				Produtos = (List<Produto>) o;
				oi.close();
				fi.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		System.out.println("***********************************");
		System.out.println("Escolha uma opção:");
		System.out.println("1. Incluir produto");
		System.out.println("2. Alterar produto");
		System.out.println("3. Excluir produto");
		System.out.println("4. Voltar");
		System.out.println("***********************************");
		List<Produto> cadastroProduto = new ArrayList<>();

		int opcao = in.nextInt();
		in.nextLine();

		switch (opcao) {
		case 1:
			System.out.println(l.listaFornecedores());
			System.out.println("Digite o numero do Fornecedor que fornece o produto:");
			int num = in.nextInt();
			in.nextLine();
			Fornecedor fornecedor = l.procurarFornecedor(num);
			if (fornecedor != null) {
				System.out.println("Digite o nome do produto:");
				String nomeProduto = in.nextLine();

				System.out.println("Digite a descricao do produto:");
				String descricaoProduto = in.nextLine();

				System.out.println("Digite o codigo do produto:");
				String codigoProduto = in.nextLine();

				System.out.println("Digite a quantidade deste produto:");
				int quant = in.nextInt();
				in.nextLine();

				System.out.println("Digite o preco do produto:");
				Double preco = in.nextDouble();
				in.nextLine();

				Estoque estoque = new Estoque(quant, preco);
				Produto produto = new Produto(nomeProduto, descricaoProduto, codigoProduto, fornecedor, estoque);

				if (l.adicionarCadastroProduto(produto)) {
					System.out.println("\nCadastro de Produto Realizado com Sucesso!\n");
				} else {
					System.out.println("\nNumero de Cadastros de produtos Excedido!\n");
				}
			} else {
				System.out.println("\nFornecedor Não Encontrado!\n");
			}
			try {
				FileOutputStream fu = new FileOutputStream("CadastroP.txt");
				ObjectOutputStream ou = new ObjectOutputStream(fu);
				ou.writeObject(cadastroProduto);
				ou.close();
				fu.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			for (Produto CP : Produtos) {
				System.out.println(CP);
			}

			break;
		case 2:
			System.out.println(l.listaProdutos());
			System.out.println("\nDigite o numero do produto que deseja alterar:");
			num = in.nextInt();
			in.nextLine();

			// List<String> NovoCadastroProduto = new ArrayList<String>();

			Produto produto = l.alterarProduto(num);
			if (produto != null) {
				System.out.println("\nDigite o que deseja alterar do produto:");
				System.out.println("1. Nome\n2. Descricao\n3. Codigo\n4. Fornecedor\n");
				opcao = in.nextInt();
				in.nextLine();

				switch (opcao) {
				case 1:
					System.out.println("\nDigite o novo nome:");
					String novoNome = in.nextLine();
					if (novoNome == null || novoNome == "" || novoNome == " ") {
						throw new NullPointerException("Espaço em branco detectado!");
					}
					produto.setNome(novoNome);
					// NovoCadastroProduto.add(novoNome);

					break;
				case 2:
					System.out.println("\nDigite a nova Descricao:");
					String novaDescricao = in.nextLine();

					produto.setDescricao(novaDescricao);
					// NovoCadastroProduto.add(novaDescricao);
					break;
				case 3:
					System.out.println("\nDigite o novo Codigo:");
					String novoCodigo = in.nextLine();

					produto.setCodigo(novoCodigo);
					// NovoCadastroProduto.add(novoCodigo);
					break;
				case 4:
					alteraFornecedor(produto.getFornecedor());
					break;
				}
				System.out.println("\nAlteracão de Cadastro de Produto Realizado com Sucesso!\n");
			} else {
				System.out.println("\nProduto não Encontrado!\n");
			}
			break;
		case 3:
			System.out.println(l.listaProdutos());
			System.out.println("Digite o número do produto que deseja excluir:");
			num = in.nextInt();
			in.nextLine();

			if (num < 0) {
				throw new NullPointerException("Numero invalido!");
			}
			if (l.excluirProduto(num)) {
				System.out.println("\nProduto excluído com Sucesso!\n");
			} else {
				System.out.println("\nProduto não Encontrado!\n");
			}
			break;
		case 4:
			break;
		default:
			System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
			System.out.println("Aviso: Opção invalida tente novamente!");
			System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
		}

	}

	@SuppressWarnings("unchecked")
	private static void cadastrarCliente() {

		List<Cliente> CadastroCliente = new ArrayList<>();

		File f = new File("CadastroCliente.txt");
		if (f.exists()) {
			try {
				FileInputStream fi = new FileInputStream("CadastroCliente.txt");
				ObjectInputStream oi = new ObjectInputStream(fi);
				Object o = oi.readObject();
				CadastroCliente = (List<Cliente>) o;
				oi.close();
				fi.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		System.out.println("Digite seu nome:");
		String nome = in.nextLine();

		System.out.println("Digite seu telefone:");
		String tel = in.nextLine();

		System.out.println("Digite seu Email:");
		String email = in.nextLine();

		System.out.println("Digite o numero do seu cartão de crédito:");
		String cartao = in.nextLine();

		System.out.println("Digite sua senha de acesso para login:");
		String senha = in.nextLine();

		Endereco endereco = cadastroEndereco();
		Cliente cliente = new Cliente(nome, senha, tel, email, cartao, endereco);
		c.addCadastroCliente(cliente);
		System.out.println("\nCadastro de Cliente Realizado com Sucesso!\n");

		try {
			FileOutputStream fu = new FileOutputStream("CadastroCliente.txt");
			ObjectOutputStream ou = new ObjectOutputStream(fu);
			ou.writeObject(CadastroCliente);
			ou.close();
			fu.close();
		} catch (Exception e) {
			e.printStackTrace();
			for (Cliente CC : CadastroCliente) {
				System.out.println(CC);
			}
		}

	}

	private static void manutenEstoque() {

		System.out.println(l.listaProdutos());
		System.out.println("\nDigite o número do produto que deseja atualizar o estoque:");
		int num = in.nextInt();
		in.nextLine();

		Produto produto = l.manutencaoEstoque(num);
		if (produto != null) {
			System.out.println("Digite a nova quantidade do produto:");
			int NovaQuantidade = in.nextInt();
			in.nextLine();

			produto.getEstoque().setQuantidade(NovaQuantidade);
			System.out.println("Digite o novo preco do produto:");
			Double NovoPreco = in.nextDouble();
			in.nextLine();

			produto.getEstoque().setPreco(NovoPreco);
			System.out.println("\nEstoque Atualizado com Sucesso!\n");
		} else {
			System.out.println("\nProduto não Encontrado!\n");
		}

	}

	private static void consultarFornecedor() {

		System.out.println("**********************************");
		System.out.println("Escolha uma opção:");
		System.out.println("1. Consultar fornecedor por nome");
		System.out.println("2. Consultar fornecedor por codigo");
		System.out.println("3. Voltar");
		System.out.println("**********************************");

		int opcao = in.nextInt();
		in.nextLine();

		switch (opcao) {
		case 1:
			System.out.println(l.listaFornecedores());
			System.out.println("\nDigite o nome a ser consultado:");
			String ConsultarNome = in.nextLine();

			String dadosFornecedor = l.consultarFornecedorPorNome(ConsultarNome);
			if (dadosFornecedor != null) {
				System.out.println(dadosFornecedor);
			} else {
				System.out.println("\nFornecedor não Encontrado!\n");
			}
			break;
		case 2:
			System.out.println(l.listaFornecedores());
			System.out.println("Digite o código do Fornecedor:");
			String consultCodigo = in.nextLine();
			if (consultCodigo == null || consultCodigo == "" || consultCodigo == " ") {
				throw new NullPointerException("Espaço em branco detectado!");
			}
			dadosFornecedor = l.consultarFornecedorPorCodigo(consultCodigo);
			if (dadosFornecedor != null) {
				System.out.println(dadosFornecedor);
			} else {
				System.out.println("\nFornecedor não Encontrado!\n");
			}
			break;
		case 3:
			break;
		default:
			System.out.println("\nOpcao invalida tente novamente!\n");
		}

	}

	private static void consultarProduto() {

		System.out.println("*******************************");
		System.out.println("Escolha uma opção:");
		System.out.println("1. Consultar produto por nome");
		System.out.println("2. Consultar Produto por codigo");
		System.out.println("3. Voltar");
		System.out.println("*******************************");

		int opcao = in.nextInt();
		in.nextLine();

		switch (opcao) {
		case 1:
			System.out.println(l.listaProdutos());
			System.out.println("Digite o nome do produto que deseja Consultar:");
			String nome = in.nextLine();
			if (nome == null || nome == "" || nome == " ") {
				throw new NullPointerException("Espaço em branco detectado!");
			}
			String dadosProduto = l.consultarProdutoPorNome(nome);
			if (dadosProduto != null) {
				System.out.println(dadosProduto);
			} else {
				System.out.println("\nProduto não Encontrado!\n");
			}
			break;
		case 2:
			System.out.println(l.listaProdutos());
			System.out.println("\nDigite o código do produto que deseja consultar:");
			String codigoProduto = in.nextLine();
			if (codigoProduto == null || codigoProduto == "" || codigoProduto == " ") {
				throw new NullPointerException("Espaço em branco detectado!");
			}
			dadosProduto = l.consultarProdutoPorCodigo(codigoProduto);
			if (dadosProduto != null) {
				System.out.println(dadosProduto);
			} else {
				System.out.println("\nProduto não Encontrado!\n");
			}
			break;
		case 3:
			break;
		default:
			System.out.println("Aviso: Opção invalida tente novamente!");
		}
	}

	private static void gerenciarProduto() {

		System.out.println("\nEfetue o seu login para ter acesso aos nossos produtos:");
		System.out.println("Digite seu nome:");
		String nome = in.nextLine();
		System.out.println("Digite sua senha:");
		String senha = in.nextLine();

		Cliente cliente = c.procuraCliente(nome, senha);

		if (cliente != null) {
			int opcao;
			Boolean continuar = true;
			while (continuar) {

				System.out.println("\nEscolha uma opção:");
				System.out.println("1. Pesquisar por Produtos");
				System.out.println("2. Ver Carrinho");
				System.out.println("3. Realizar Pedido");
				System.out.println("4. Consultar Pedido por Número");
				System.out.println("5. Sair da conta (Voltar ao menu principal)");
				System.out.print("Escolha uma opção: ");
				opcao = in.nextInt();
				in.nextLine();

				switch (opcao) {
				case 1:
					pesquisarProduto(cliente);
					break;
				case 2:
					mostrarCarrinho(cliente);
					break;
				case 3:
					realizarPedido(cliente);
					break;
				case 4:
					mostrarPedidoNumero(cliente);
					break;
				case 5:
					continuar = false;
					break;
				default:
					System.out.println("Opção inválida, tente novamente!\n");
				}

			}
		} else {
			System.out.println("\nCliente não Cadastrado! Faça seu cadastro\n");

		}
	}

	public static void consultarPedidoNumeroAdm() {

		int cont = 0;
		System.out.println("\nLista de Pedidos de Clientes:");
		for (int i = 0; i < c.getCadastrosClientes().size(); i++) {
			if (c.getCadastrosClientes().get(i).getPedidos().isEmpty()) {
				cont++;
			} else {
				System.out.println(c.getCadastrosClientes().get(i).listaPedido(c.getCadastrosClientes().get(i)));
			}
		}
		if (c.getCadastrosClientes().size() == cont) {
			System.out.println("\nNenhum Pedido feito no Momento!\n");
		} else {
			System.out.println("Digite o numero do pedido:");
			int n = in.nextInt();
			in.nextLine();
			if (n <= 0) {
				throw new NullPointerException("Numero invalido!");
			}
			for (int j = 0; j < c.getCadastrosClientes().size(); j++) {
				for (int x = 0; x < c.getCadastrosClientes().size(); x++) {
					if (c.getCadastrosClientes().get(j).getPedidos().get(x).getNumero() == n) {
						Cliente cliente = c.getCadastrosClientes().get(j);
						System.out.println(cliente.mostrarPedido(cliente, n));
						System.out.println("\nDeseja Alterar o Status do pedido?");
						System.out.print("1. Sim\n2. Não\nDigite: ");
						int nu = in.nextInt();
						in.nextLine();
						if (nu <= 0) {
							throw new NullPointerException("Numero invalido!");
						}
						switch (nu) {
						case 1:
							System.out.println("Selecione o status do pedido:");
							System.out.print("1. Entregue\n2. Cancelado\nDigite: ");
							int op = in.nextInt();
							if (op <= 0) {
								throw new NullPointerException("Numero invalido!");
							}
							switch (op) {
							case 1:
								c.getCadastrosClientes().get(j).getPedidos().get(x).setSituacao("Entregue");
								System.out.println("\nStatus de pedido atualizado com sucesso!\n");
								break;
							case 2:
								c.getCadastrosClientes().get(j).getPedidos().get(x).setSituacao("Cancelado");
								System.out.println("\nStatus de pedido atualizado com sucesso!\n");
								break;
							}
							break;
						case 2:
							break;
						}
					}
				}
			}
		}

	}

	private static void pesquisarProduto(Cliente cliente) {
		System.out.println("\nDigite a palavra-chave do produto que deseja pesquisar:");
		String palavra = in.nextLine();
		List<Produto> produtos = l.produtoPesquisado(palavra);
		if (produtos.isEmpty()) {
			System.out.println("\nNenhum Produto Encontrado!\n");
		} else {
			System.out.println("\n******Lista de produtos relacionados:******");
			for (int i = 0; i < produtos.size(); i++) {
				if (produtos.get(i).getEstoque().getQuantidade() <= 0) {
					System.out.println((i + 1) + ". Nome: " + produtos.get(i).getNome() + "  Indisponível no momento!");
				} else {
					System.out.println((i + 1) + ". Nome: " + produtos.get(i).getNome() + "   R$ "
							+ produtos.get(i).getEstoque().getPreco());
				}
			}
			System.out.println("*******************************************");
			System.out.println("\nDigite o indice do produto que deseja adicionar no carrinho:");
			int indice = in.nextInt();
			in.nextLine();
			indice -= 1;
			if (indice >= 0 && indice < produtos.size()) {
				Produto produtoSelecionado = produtos.get(indice);
				if (produtoSelecionado.getEstoque().getQuantidade() <= 0) {
					System.out.println("\nProduto sem Estoque de Unidades!");
				} else {
					System.out.println("Digite a quantidade que deseja comprar:");
					int quant = in.nextInt();
					in.nextLine();
					if (quant > 0 && quant <= produtoSelecionado.getEstoque().getQuantidade()) {
						Double total = 0d;
						total = quant * produtoSelecionado.getEstoque().getPreco();
						System.out.println("\n\nProduto Selecionado:\nNome: " + produtoSelecionado.getNome());
						System.out.println("Quantidade: " + quant);
						System.out.format("Total do Item: R$ %.2f", total);
						System.out.print("\nDeseja adicionar no carrinho?\n1. Sim\n2. Não\nDigite: ");
						int opcao = in.nextInt();
						in.nextLine();
						switch (opcao) {
						case 1:
							cliente.addItem(quant, total, produtoSelecionado);
							System.out.println("\nProduto adicionado com sucesso no Carrinho!\n");
							break;
						case 2:
							System.out.println("\nCancelado!\n");
							break;
						}
					} else {
						System.out.println("\nQuantidade Inválida! Existem "
								+ produtoSelecionado.getEstoque().getQuantidade() + " Un em estoque!" + "\n");
						System.out.println("Deseja adicionar " + produtoSelecionado.getEstoque().getQuantidade()
								+ "Un no carrinho?");
						Double total = 0d;
						total = produtoSelecionado.getEstoque().getQuantidade() * produtoSelecionado.getEstoque().getPreco();
						System.out.println("\n\nProduto Selecionado:\nNome: " + produtoSelecionado.getNome());
						System.out.println("Quantidade: " + produtoSelecionado.getEstoque().getQuantidade());
						System.out.format("Total do Item R$ %.2f", total);
						System.out.print("\nAdicionar?\n1. Sim\n2. Não\nDigite: ");
						int opcao = in.nextInt();
						in.nextLine();
						switch (opcao) {
						case 1:
							cliente.addItem(produtoSelecionado.getEstoque().getQuantidade(), total, produtoSelecionado);
							System.out.println("\nProduto adicionado com sucesso no Carrinho!\n");
							break;
						case 2:
							System.out.println("\nCancelado!\n");
							break;
						}
					}
				}
			} else {
				System.out.println("\nProduto não Encontrado!\n");
			}
		}
	}

	private static void mostrarCarrinho(Cliente cliente) {

		System.out.println("\n********Carrinho de compras********");
		if (cliente.getCarrinho().isEmpty()) {
			System.out.println("\nNenhum produto adicionado ao carrinho!\n");
		} else {
			for (int i = 0; i < cliente.getCarrinho().size(); i++) {
				System.out.println("Produto: " + cliente.getCarrinho().get(i).getProduto().getNome() + " Quantidade: "
						+ cliente.getCarrinho().get(i).getQuantidade() + " R$ Un "
						+ cliente.getCarrinho().get(i).getProduto().getEstoque().getPreco());
			}
			System.out.println("\nValor total de Produtos no carrinho R$ " + cliente.getTotal());
		}
		System.out.println("-------------------------------------");

	}

	private static void realizarPedido(Cliente cliente) {
		mostrarCarrinho(cliente);
		if (!cliente.getCarrinho().isEmpty()) {
			Double icms = (cliente.getTotal() * 0.17);
			System.out.format("\nICMS R$: %.2f", icms);
			System.out.format("\nSubTotal: R$ %.2f", (icms + cliente.getTotal()));
			System.out.println("\n\nDeseja confirmar o Pedido?\n1. Sim\n2. Não");

			int opcao = in.nextInt();
			in.nextLine();

			switch (opcao) {
			case 1:
				Random gerador = new Random();
				Pedido pedido = new Pedido(gerador.nextInt(100) + 1, new Date(), new Date());
				for (int i = 0; i < cliente.getCarrinho().size(); i++) {
					ItemPedido item = cliente.getCarrinho().get(i);
					l.alterarEstoque(item.getProduto().getNome(), item.getQuantidade());
					pedido.addPedido(item);
				}
				cliente.addPedido(pedido);
				cliente.limparCarrinho(cliente);
				cliente.zerarValor();
				System.out.println("\nO Pedido foi realizado com sucesso!");
				break;
			case 2:
				System.out.println("\nO Pedido foi cancelado!");
				break;
			}

		}
	}

	public static void mostrarPedidoNumero(Cliente cliente) {

		if (!cliente.getPedidos().isEmpty()) {
			System.out.println("\n\nLista de seus Pedidos:");
			System.out.println(cliente.listaPedido(cliente));
			System.out.println("Digite o numero do pedido");
			int n = in.nextInt();
			in.nextLine();

			System.out.println(cliente.mostrarPedido(cliente, n));

		} else {
			System.out.println("\n\nVocê Ainda Não Possui Pedidos!\n");
		}

	}

	@SuppressWarnings("unchecked")
	public static Endereco cadastroEndereco() {
		List<Endereco> CadastroEndereco = new ArrayList<>();
		File f = new File("CadastroEndereco.txt");
		if (f.exists()) {
			try {
				FileInputStream fi = new FileInputStream("CadastroEndereco.txt");
				ObjectInputStream oi = new ObjectInputStream(fi);
				Object o = oi.readObject();
				CadastroEndereco = (List<Endereco>) o;
				oi.close();
				fi.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		System.out.println("Digite a rua:");
		String rua = in.nextLine();

		System.out.println("Digite o numero:");
		String numero = in.nextLine();

		System.out.println("Digite o complemento:");
		String complemento = in.nextLine();

		System.out.println("Digite o bairro:");
		String bairro = in.nextLine();

		System.out.println("Digite o CEP:");
		String cep = in.nextLine();

		System.out.println("Digite a Cidade:");
		String cidade = in.nextLine();

		System.out.println("Digite o Estado:");
		String estado = in.nextLine();

		Endereco endereco = new Endereco(rua, numero, complemento, bairro, cep, cidade, estado);

		try {
			FileOutputStream fu = new FileOutputStream("CadastroEndereco.txt");
			ObjectOutputStream ou = new ObjectOutputStream(fu);
			ou.writeObject(CadastroEndereco);
			ou.close();
			fu.close();
			for (Endereco CE : CadastroEndereco) {
				System.out.println(CE);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return endereco;

	}

	@SuppressWarnings("unchecked")
	private static void alteraFornecedor(Fornecedor fornecedor) {
		System.out.println("\nDIGITE O QUE DESEJA ALTERAR DO FORNECEDOR:\n");
		System.out.println("1. Nome\n2. Descricao\n3. Telefone\n4. E-mail\n5. Codigo\n6. Endereco\n");
		int opcoes = in.nextInt();
		in.nextLine();
		List<Fornecedor> NovoFornecedor = new ArrayList<>();

		File f = new File("CadastroNovoFornecedor.txt");
		if (f.exists()) {
			try {
				FileInputStream fi = new FileInputStream("CadastroNovoFornecedor.txt");
				ObjectInputStream oi = new ObjectInputStream(fi);
				Object o = oi.readObject();
				NovoFornecedor = (List<Fornecedor>) o;
				oi.close();
				fi.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		switch (opcoes) {
		case 1:
			System.out.println("Digite o novo nome do Fornecedor:");
			String novoNome = in.nextLine();

			fornecedor.setNome(novoNome);

			break;
		case 2:
			System.out.println("Digite a nova descricao do Fornecedor:");
			String novaDescricao = in.nextLine();

			fornecedor.setDescricao(novaDescricao);

			break;
		case 3:
			System.out.println("Digite o novo telefone do Fornecedor:");
			String novoTel = in.nextLine();

			fornecedor.setTelefone(novoTel);

			break;
		case 4:
			System.out.println("Digite o novo E-mail do Fornecedor:");
			String novoEmail = in.nextLine();

			fornecedor.setEmail(novoEmail);

			break;
		case 5:
			System.out.println("Digite o novo Codigo do Fornecedor:");
			String novoCod = in.nextLine();

			fornecedor.setCodigo(novoCod);
			break;
		case 6:
			System.out.println("Digite a nova rua:");
			String novaRua = in.nextLine();

			fornecedor.getEndereco().setRua(novaRua);
			System.out.println("Digite o novo numero:");
			String novoNumero = in.nextLine();

			fornecedor.getEndereco().setNumero(novoNumero);
			System.out.println("Digite o novo complemento:");
			String novoComplemento = in.nextLine();

			fornecedor.getEndereco().setComplemento(novoComplemento);
			System.out.println("Digite o novo bairro:");
			String novoBairro = in.nextLine();

			fornecedor.getEndereco().setBairro(novoBairro);
			System.out.println("Digite o novo CEP:");
			String novoCep = in.nextLine();

			fornecedor.getEndereco().setCep(novoCep);
			System.out.println("Digite a nova Cidade:");
			String novaCidade = in.nextLine();

			fornecedor.getEndereco().setCidade(novaCidade);
			System.out.println("Digite o novo Estado:");
			String novoEstado = in.nextLine();

			fornecedor.getEndereco().setEstado(novoEstado);
			try {
				FileOutputStream fu = new FileOutputStream("CadastroNovoFornecedor.txt");
				ObjectOutputStream ou = new ObjectOutputStream(fu);
				ou.writeObject(NovoFornecedor);
				ou.close();
				fu.close();
				for (Fornecedor NF : NovoFornecedor) {
					System.out.println(NF);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			break;
		default:
			System.out.println("\nOpcao inválida tente novamente!\n");
		}
	}

}
