package parte1;

public class Menu {

}
