package parte1;

import java.io.Serializable;

import parte2.Cliente;

public class Produto implements Serializable {
	private static final long serialVersionUID = 1L;
	private Cliente cliente;
	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private String nome;
	private String descricao;
	private String codigo;
	private Fornecedor fornecedor;
	private Estoque estoque;
	private int numero;

	public Produto(String nome, String descricao, String codigo) {
		this.nome = nome;
		this.descricao = descricao;
		this.codigo = codigo;
	}

	public Produto(String nome, String descricao, String codigo, Fornecedor fornecedor, Estoque estoque) {
		this.nome = nome;
		this.descricao = descricao;
		this.codigo = codigo;
		this.fornecedor = fornecedor;
		this.estoque = estoque;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public Fornecedor getFornecedor() {
		return fornecedor;
	}

	public void setFornecedor(Fornecedor fornecedor) {
		this.fornecedor = fornecedor;
	}

	public Estoque getEstoque() {
		return estoque;
	}

	public void setEstoque(Estoque estoque) {
		this.estoque = estoque;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

}
