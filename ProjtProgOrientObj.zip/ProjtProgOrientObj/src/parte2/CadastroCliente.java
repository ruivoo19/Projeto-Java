package parte2;

import java.util.List;
import java.util.ArrayList;

public class CadastroCliente {
	private List<Cliente> cadastros;

	public CadastroCliente() {
		cadastros = new ArrayList<>();
	}

	public List<Cliente> getCadastrosClientes() {
		return cadastros;
	}

	public void addCadastroCliente(Cliente cliente) {
		cadastros.add(cliente);
	}

	public void removerCliente(Cliente cliente) {
		cadastros.remove(cliente);
	}

	public Cliente procuraCliente(String nome, String senha) {
		for (int i = 0; i < cadastros.size(); i++) {
			if (cadastros.get(i).getNome().equalsIgnoreCase(nome) && cadastros.get(i).getSenha().equals(senha)) {
				return cadastros.get(i);
			}
		}
		return null;
	}
}
