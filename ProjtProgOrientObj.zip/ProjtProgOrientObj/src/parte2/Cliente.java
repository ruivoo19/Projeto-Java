package parte2;

import parte1.*;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.ArrayList;

public class Cliente implements Serializable {
	private static final long serialVersionUID = 1L;
	public Carrinho getC() {
		return c;
	}

	public void setC(Carrinho c) {
		this.c = c;
	}

	public SimpleDateFormat getSdf() {
		return sdf;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private String nome;
	private String senha;
	private String telefone;
	private String email;
	private String cartaoCredito;
	private Endereco endereco;
	private List<Pedido> pedidos;
	private Carrinho c;
	private final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

	public Cliente(String nome, String senha, String telefone, String email, String cartaoCredito, Endereco endereco) {
		this.nome = nome;
		this.senha = senha;
		this.telefone = telefone;
		this.email = email;
		this.cartaoCredito = cartaoCredito;
		this.endereco = endereco;
		pedidos = new ArrayList<>();
		c = new Carrinho();
	}

	public List<Pedido> getPedidos() {
		return pedidos;
	}

	public void addPedido(Pedido pedido) {
		this.pedidos.add(pedido);
	}

	public void setPedidos(List<Pedido> pedidos) {
		this.pedidos = pedidos;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getSenha() {
		return senha;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCartaoCredito() {
		return cartaoCredito;
	}

	public void setCartaoCredito(String cartaoCredito) {
		this.cartaoCredito = cartaoCredito;
	}

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}

	public void criaCarrinho() {
		c.criarCarrinho();
	}

	public List<ItemPedido> getCarrinho() {
		return c.getCarrinho();
	}

	public Double getTotal() {
		return c.getTotalCarrinho();
	}

	public void addItem(int quant, Double preco, Produto produto) {
		c.adicionarItem(quant, preco, produto);
	}

	public String mostrarPedido(Cliente cliente, int num){
		Double total = 0d;
		int flag = 0;
		StringBuilder sb = new StringBuilder();
		if(!cliente.getPedidos().isEmpty()) {
			for(int i=0; i<cliente.getPedidos().size(); i++){
				if(cliente.pedidos.get(i).getNumero() == num) {
					flag = 1;
					sb.append("\n-------------------------Pedido----------------------------\n");
					sb.append("Cliente: "+cliente.getNome()+"\nNúmero: "+cliente.pedidos.get(i).getNumero()+
					"\nData: "+sdf.format(cliente.pedidos.get(i).getDataPedido())+"\nSituação: "+cliente.pedidos.get(i).getSituacao());
					sb.append("\n\n---------------------Dados do Pedido-----------------------\n");
					for(int j=0; j<cliente.getPedidos().get(i).getItensPedidos().size(); j++) {
						sb.append("\n\nNome do Produto: "+cliente.getPedidos().get(i).getItensPedidos().get(j).getProduto().getNome()+"\nQuantidade: "
						+cliente.getPedidos().get(i).getItensPedidos().get(j).getQuantidade()+"\nValor Total do Item R$ "+cliente.getPedidos().get(i).getItensPedidos().get(j).getPreco()+"\nValor Un R$ "+
						cliente.getPedidos().get(i).getItensPedidos().get(j).getProduto().getEstoque().getPreco());
						total += cliente.getPedidos().get(i).getItensPedidos().get(j).getPreco();
					}
					sb.append("\n\nTotal do Pedido + ICMS R$: "+((total*0.17)+total));
					sb.append("\n-----------------------------------------------------------");
				}
			}
		}
		else {
			sb.append("\nNenhum Pedido Encontrado!\n");
		}
		if(flag == 0) {
			sb.append("\nNenhum Pedido Encontrado!\n");
		}
		return sb.toString();
	}


	public void limparCarrinho(Cliente cliente) {
		c.limparCarrinho();
	}

	public void zerarValor() {
		c.zerar();
	}

	public String listaPedido(Cliente cliente) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < cliente.getPedidos().size(); i++) {
			sb.append("\nN° Pedido:  " + cliente.getPedidos().get(i).getNumero() + "\n");
		}
		return sb.toString();
	}

}
