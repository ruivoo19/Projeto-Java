package parte2;

import parte1.Produto;
import java.util.ArrayList;
import java.util.List;

public class ItemPedido {
	private int quantidade;
	private Double preco;
	private List<Produto> produtos;
	private Produto produto;

	public ItemPedido(int quantidade, Double preco, Produto produto) {
		produtos = new ArrayList<>();
		produtos.add(produto);
		this.produto = produto;
		this.quantidade = quantidade;
		this.preco = preco;
	}

	public int getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}

	public Double getPreco() {
		return preco;
	}

	public void setPreco(Double preco) {
		this.preco = preco;
	}

	public Produto getProduto() {
		return produto;
	}

	public void setItens(List<Produto> produtos) {
		this.produtos = produtos;
	}

	public void addProdutos(Produto produto) {
		produtos.add(produto);
	}

	public String toString(int pos) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < produtos.size(); i++) {
			sb.append("Nome do Produto: " + produtos.get(i).getNome() + "\nDescrição: " + produtos.get(i).getDescricao()
					+ "\nValor Unidade R$ " + produtos.get(i).getEstoque().getPreco());
		}
		return sb.toString();
	}

}
