package parte2;

import java.util.ArrayList;
import java.util.List;
import java.util.Date;

public class Pedido {
	private int numero;
	private Date dataPedido;
	private Date dataEntrega;
	private String situacao;
	List<ItemPedido> itensPedidos;

	public Pedido(int numero, Date dataPedido, Date dataEntrega) {
		this.itensPedidos = new ArrayList<>();
		this.numero = numero;
		this.dataPedido = dataPedido;
		this.dataEntrega = dataEntrega;
		this.situacao = "Novo";
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public Date getDataPedido() {
		return dataPedido;
	}

	public void setDataPedido(Date dataPedido) {
		this.dataPedido = dataPedido;
	}

	public Date getDataEntrega() {
		return dataEntrega;
	}

	public void setDataEntrega(Date dataEntrega) {
		this.dataEntrega = dataEntrega;
	}

	public String getSituacao() {
		return situacao;
	}

	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}

	public List<ItemPedido> getItensPedidos() {
		return itensPedidos;
	}

	public void setItensPedidos(List<ItemPedido> produtos) {
		this.itensPedidos = produtos;
	}

	public void addPedido(ItemPedido item) {
		itensPedidos.add(item);
	}

}
