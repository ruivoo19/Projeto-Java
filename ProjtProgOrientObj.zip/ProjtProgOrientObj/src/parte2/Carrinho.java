package parte2;

import java.util.List;

import parte1.Produto;

import java.util.ArrayList;

public class Carrinho {
	private List<ItemPedido> produtos;
	private Double totalCarrinho;

	public Carrinho() {
			this.totalCarrinho = 0d;
	}

	public void criarCarrinho() {
		produtos = new ArrayList<>();
		this.totalCarrinho = 0d;
	}

	public void adicionarItem(int quantidade, Double total, Produto produto) {
		this.totalCarrinho += total;
		ItemPedido item = new ItemPedido(quantidade, total, produto);
		produtos.add(item);
	}

	public Double getTotalCarrinho() {
		return this.totalCarrinho;
	}

	public List<ItemPedido> getCarrinho() {
		return produtos;
	}

	public void limparCarrinho() {
		produtos.clear();
	}

	public void zerar() {
		totalCarrinho = 0d;
	}

}
